#ifndef COMMON_H
#define COMMON_H

#include <QTime>
#include <QCoreApplication>

class Common
{
public:
    Common();
    void Delay(unsigned int ms);
};

#endif // COMMON_H
